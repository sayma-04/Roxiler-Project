const express = require('express');
const router = express.Router();
const axios = require('axios');
const ProductTransaction = require('../models/ProductTransaction');

// Seed Data API: Fetch data from third-party API and seed MongoDB
router.get('/seed', async (req, res) => {
  try {
    const response = await axios.get('https://s3.amazonaws.com/roxiler.com/product_transaction.json');
    await ProductTransaction.insertMany(response.data);
    res.json({ message: 'Database seeded successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Error seeding database', error });
  }
});

// List Transactions API with Pagination and Search
router.get('/transactions', async (req, res) => {
  const { page = 1, perPage = 10, search = '' } = req.query;
  const query = search
    ? {
        $or: [
          { title: { $regex: search, $options: 'i' } },
          { description: { $regex: search, $options: 'i' } },
          { price: { $regex: search, $options: 'i' } },
        ],
      }
    : {};
  try {
    const transactions = await ProductTransaction.find(query)
      .skip((page - 1) * perPage)
      .limit(parseInt(perPage));
    res.json(transactions);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching transactions', error });
  }
});

// Statistics API
router.get('/statistics', async (req, res) => {
  const { month } = req.query;
  const start = new Date(`${month}-01`);
  const end = new Date(start);
  end.setMonth(end.getMonth() + 1);
  try {
    const transactions = await ProductTransaction.find({
      dateOfSale: { $gte: start, $lt: end },
    });
    const totalSaleAmount = transactions.reduce((sum, transaction) => sum + transaction.price, 0);
    const soldItems = transactions.filter(t => t.isSold).length;
    const unsoldItems = transactions.length - soldItems;
    res.json({ totalSaleAmount, soldItems, unsoldItems });
  } catch (error) {
    res.status(500).json({ message: 'Error fetching statistics', error });
  }
});

// Bar Chart API
router.get('/bar-chart', async (req, res) => {
  const { month } = req.query;
  const start = new Date(`${month}-01`);
  const end = new Date(start);
  end.setMonth(end.getMonth() + 1);
  try {
    const transactions = await ProductTransaction.find({
      dateOfSale: { $gte: start, $lt: end },
    });
    const priceRanges = {
      '0-100': 0,
      '101-200': 0,
      '201-300': 0,
      '301-400': 0,
      '401-500': 0,
      '501-600': 0,
      '601-700': 0,
      '701-800': 0,
      '801-900': 0,
      '901-above': 0,
    };
    transactions.forEach(t => {
      if (t.price <= 100) priceRanges['0-100']++;
      else if (t.price <= 200) priceRanges['101-200']++;
      else if (t.price <= 300) priceRanges['201-300']++;
      else if (t.price <= 400) priceRanges['301-400']++;
      else if (t.price <= 500) priceRanges['401-500']++;
      else if (t.price <= 600) priceRanges['501-600']++;
      else if (t.price <= 700) priceRanges['601-700']++;
      else if (t.price <= 800) priceRanges['701-800']++;
      else if (t.price <= 900) priceRanges['801-900']++;
      else priceRanges['901-above']++;
    });
    res.json(priceRanges);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching bar chart data', error });
  }
});

// Pie Chart API
router.get('/pie-chart', async (req, res) => {
  const { month } = req.query;
  const start = new Date(`${month}-01`);
  const end = new Date(start);
  end.setMonth(end.getMonth() + 1);
  try {
    const categories = await ProductTransaction.aggregate([
      { $match: { dateOfSale: { $gte: start, $lt: end } } },
      { $group: { _id: '$category', count: { $sum: 1 } } },
    ]);
    res.json(categories);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching pie chart data', error });
  }
});

module.exports = router;
