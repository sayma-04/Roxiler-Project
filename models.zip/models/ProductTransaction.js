const mongoose = require('mongoose');

const ProductTransactionSchema = new mongoose.Schema({
  title: String,
  description: String,
  price: Number,
  isSold: Boolean,
  category: String,
  dateOfSale: Date
});

module.exports = mongoose.model('ProductTransaction', ProductTransactionSchema);
