import React, { useState, useEffect } from 'react';
import axios from 'axios';

function Statistics({ selectedMonth }) {
  const [statistics, setStatistics] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    setLoading(true);
    axios.get(`http://localhost:5000/api/statistics?month=${selectedMonth}`)
      .then(response => {
        setStatistics(response.data);
        setLoading(false);
      })
      .catch(error => {
        setError(error.message);
        setLoading(false);
      });
  }, [selectedMonth]);

  if (loading) return <p>Loading statistics...</p>;
  if (error) return <p>Error: {error}</p>;

  return (
    <div>
      <h2>Statistics for {selectedMonth}</h2>
      <p>Total Sale Amount: ${statistics.totalSaleAmount}</p>
      <p>Sold Items: {statistics.soldItems}</p>
      <p>Unsold Items: {statistics.unsoldItems}</p>
    </div>
  );
}

export default Statistics;
