import React, { useState, useEffect } from 'react';
import { Bar } from 'react-chartjs-2'; 
import axios from 'axios';

function BarChart({ selectedMonth }) {
  const [barData, setBarData] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchBarData = async () => {
      setLoading(true);
      try {
        const response = await axios.get('http://localhost:5000/api/bar-chart', {
          params: {
            month: selectedMonth, 
          },
        });

        const labels = Object.keys(response.data); 
        const data = Object.values(response.data); 

        setBarData({
          labels, 
          datasets: [
            {
              label: 'Number of Items',
              data, 
              backgroundColor: 'rgba(75, 192, 192, 0.6)', // Bar color
            },
          ],
        });

        setLoading(false);
      } catch (err) {
        setError(err.message);
        setLoading(false);
      }
    };

    fetchBarData();
  }, [selectedMonth]); 

  // Loading or error states
  if (loading) return <p>Loading bar chart...</p>;
  if (error) return <p>Error: {error}</p>;

  return (
    <div style={styles.chartContainer}>
      <h2>Items in Price Range for {selectedMonth}</h2>
      <Bar data={barData} />
    </div>
  );
}

// Inline styles for the chart container
const styles = {
  chartContainer: {
    maxWidth: '600px',
    margin: '0 auto',
    padding: '20px',
    border: '1px solid #ccc',
    borderRadius: '5px',
    backgroundColor: '#f9f9f9',
  },
};

export default BarChart;
