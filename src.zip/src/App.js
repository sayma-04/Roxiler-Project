import React, { useState } from 'react';  
import Statistics from './components/Statistics';  
import BarChart from './components/BarChart';  
import PieChart from './components/PieChart';  

function App() {
 
  const [selectedMonth, setSelectedMonth] = useState('January');


  const handleMonthChange = (e) => {
    setSelectedMonth(e.target.value);
  };

  return (
    <div>
      <h1>Transactions Dashboard</h1>

      {/* Dropdown list for months */}
      <label htmlFor="month">Select Month:</label>
      <select id="month" value={selectedMonth} onChange={handleMonthChange}>
        <option>January</option>
        <option>February</option>
        <option>March</option>
        <option>April</option>
        <option>May</option>
        <option>June</option>
        <option>July</option>
        <option>August</option>
        <option>September</option>
        <option>October</option>
        <option>November</option>
        <option>December</option>
      </select>

      {/* Render Statistics, BarChart, and PieChart components and pass selectedMonth as a prop */}
      <Statistics selectedMonth={selectedMonth} />
      <BarChart selectedMonth={selectedMonth} />
      <PieChart selectedMonth={selectedMonth} />
    </div>
  );
}

export default App;
